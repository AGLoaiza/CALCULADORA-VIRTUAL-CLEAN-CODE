package calculadora;

import java.util.Scanner;

/**
 *
 * @author ALFONSO GUSTAVO LOAIZA SIBAJA
 */
public class calculadora {

    Operacion objeto = new Operacion();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner leer = new Scanner(System.in);

        int option = 0, Continua = 0;
        double Numero1, Numero2, Resultado = 0;

        do {
            System.out.println("*********Bienveido a la Calculadora Virtual ************");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multipliacion");
            System.out.println("4. Division");
            System.out.println("5. Salir");

            option = leer.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Vamos a Sumar");
                    System.out.println("Ingrese el primer numero");
                    Numero1 = leer.nextDouble();
                    System.out.println("Ingrese el segundo numero");
                    Numero2 = leer.nextDouble();
                    Resultado = Numero1 + Numero2;
                    System.out.println("El resultado es = " + Resultado);
                    if (Operacion.esPrimo((int) Resultado)) {
                        System.out.println("Es primo");
                    } else {
                        System.out.println("No es primo");
                    }
                    if (Operacion.isPalindrome((int) Resultado)) {
                        System.out.println("Es palindromo");
                    } else {
                        System.out.println("No es palindromo");
                    }
                    System.out.println("Desea Continuar 1) SI 2) No");
                    Continua = leer.nextInt();
                    break;
                    
                case 2:
                    System.out.println("Vamos a Restar");
                    System.out.println("Ingrese el primer numero");
                    Numero1 = leer.nextDouble();
                    System.out.println("Ingrese el segundo numero");
                    Numero2 = leer.nextDouble();
                    Resultado = Numero1 - Numero2;
                    System.out.println("El resultado es = " + Resultado);
                    if (Operacion.esPrimo((int) Resultado)) {
                        System.out.println("Es primo");
                    } else {
                        System.out.println("No es primo");
                    }
                    if (Operacion.isPalindrome((int) Resultado)) {
                        System.out.println("Es palindromo");
                    } else {
                        System.out.println("No es palindromo");
                    }
                    
                    System.out.println("Desea Continuar 1) SI 2) No");
                    Continua = leer.nextInt();
                    break;
                case 3:
                    System.out.println("Vamos a Multiplicar");
                    System.out.println("Ingrese el primer numero");
                    Numero1 = leer.nextDouble();
                    System.out.println("Ingrese el segundo numero");
                    Numero2 = leer.nextDouble();
                    Resultado = Numero1 * Numero2;
                    if (Operacion.esPrimo((int) Resultado)) {
                        System.out.println("Es primo");
                    } else {
                        System.out.println("No es primo");
                    }
                    if (Operacion.isPalindrome((int) Resultado)) {
                        System.out.println("Es palindromo");
                    } else {
                        System.out.println("No es palindromo");
                    }
                    System.out.println("El resultado es = " + Resultado);

                    System.out.println("Desea Continuar 1) SI 2) No");
                    Continua = leer.nextInt();
                    break;
                case 4:
                    System.out.println("Vamos a Dividir");
                    System.out.println("Ingrese el primer numero");
                    Numero1 = leer.nextDouble();
                    System.out.println("Ingrese el segundo valor");
                    Numero2 = leer.nextDouble();
                    Resultado = Numero1 / Numero2;
                    if (Operacion.esPrimo((int) Resultado)) {
                        System.out.println("Es primo");
                    } else {
                        System.out.println("No es primo");
                    }
                    if (Operacion.isPalindrome((int) Resultado)) {
                        System.out.println("Es palindromo");
                    } else {
                        System.out.println("No es palindromo");
                    }
                    System.out.println("El resultado es = " + Resultado);

                    System.out.println("Desea Continuar 1) SI 2) No");
                    Continua = leer.nextInt();
                    break;
                case 5:
                    System.out.println("Saliste del programa");
                    break;
                default:
                    System.out.println("La opcion no es  valida");
            }
        } while (option != 5 && Continua == 1);
    }
}
